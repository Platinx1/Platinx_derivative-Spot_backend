const OpenAI = require("openai");

const client = new OpenAI({
  baseURL: "https://openrouter.ai/api/v1",
  apiKey: "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",
});

async function test() {
  try {
    const response = await client.chat.completions.create({
      // model: "openai/gpt-4o",
      model: "openai/gpt-3.5-turbo",
      // model: "openai/gpt-5",
      messages: [
        {
          role: "user",
          content: "What is the meaning of life?", 
        },
      ],
    });

    console.log("✅ API key works!");
    console.log(response.choices[0].message.content);
  } catch (error) {
    console.log("❌ API key failed!");
    console.log(error.message);
  }
}

test();