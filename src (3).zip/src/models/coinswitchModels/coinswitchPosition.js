const mongoose = require("mongoose");
const { D } = require("../pi42Models/decimal");
const { Schema } = mongoose;

const coinswitchPositionSchema = new Schema(
  {
    coinswitchAccount: {
      type: Schema.Types.ObjectId,
      ref: "CoinSwitchSpotAccount",
      required: true,
      index: true,
    },

    symbol: {
      type: String,
      required: true,
      uppercase: true,
      trim: true,
    },

    // ─── Core Holdings ─────────────────────
    totalQuantity: { ...D("0") },
    
    // ─── Price & Investment Info ─────────────────────
    averageBuyPrice: { ...D("0") }, 
    totalInvested: { ...D("0") },

    lastUpdatedAt: { type: Date, default: Date.now },

    isActive: { type: Boolean, default: true },
    isDeleted: { type: Boolean, default: false },
  },
  {
    timestamps: true,
    toJSON: { getters: true },
    toObject: { getters: true },
  }
);

// Indexes
coinswitchPositionSchema.index({ coinswitchAccount: 1, symbol: 1 }, { unique: true });
coinswitchPositionSchema.index({ coinswitchAccount: 1 });

const CoinswitchPosition = mongoose.model("CoinswitchPosition", coinswitchPositionSchema);
module.exports = CoinswitchPosition;