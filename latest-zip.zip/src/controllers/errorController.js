const AppError = require("../utils/AppError");

// const errorDev = (err, req, res) => {
//   return res.status(err.statusCode).json({
//     status: err.status,
//     error: err,
//     message: err.message,
//   });
// };


const errorDev = (err, req, res) => {
  // console.error("Error details:", err); // Log the full error object for debugging
  return res.status(err.statusCode).json({
    status: err.status,
    // ❌ DON'T send the full error object - it may have circular references
    // error: err,  
    message: err.message,
    stack: err.stack, // Optional: include stack trace for debugging
    // If you need error details, extract safe properties only:
    ...(err.code && { code: err.code }),
    ...(err.response && { 
      apiError: {
        status: err.response.status,
        statusText: err.response.statusText,
        data: err.response.data
      }
    })
  });
};

const handleCastErrorDB = (err) => {
  const message = `Invalid ${err.path}: ${err.value}.`;
  return new AppError(message, 400);
};

const handleDuplicateFieldsDB = (err) => {
  const value = err.message.match(/(["'])(\\?.)*?\1/)[0];
  const message = `Please use another value. Duplicate field value: ${value}. `;

  return new AppError(message, 400);
};

const handleValidationErrorDB = (err) => {
  const errors = Object.values(err.errors).map((el) => el.message);
  
  const message = `Invalid input data. ${errors.join(". ")}`;
  return new AppError(message, 400);
};

const handleJWTError = () =>
  new AppError("Invalid token. Please log in again!", 401);

const handleJWTExpiredError = () =>
  new AppError("Your token has expired! Please log in again.", 401);

const globalErrorHandler = (err, req, res, next) => {
  err.statusCode = err.statusCode || 500;
  err.status = err.status || false;
  let error = { ...err };
  error.message = err.message;

  if (error.name === "CastError") error = handleCastErrorDB(error);
  if (error.code === 11000) error = handleDuplicateFieldsDB(error);
  if (error.name === "ValidationError") error = handleValidationErrorDB(error);
  if (error.name === "JsonWebTokenError") error = handleJWTError();
  if (error.name === "TokenExpiredError") error = handleJWTExpiredError();

  errorDev(error, req, res);

  next();
};

module.exports = globalErrorHandler;
